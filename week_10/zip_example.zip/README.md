# mw-scripts

<h2>Password generator</h2>
password.py

<h2>Command-line rock-paper-scissors</h2>
rockpaperscissors.py

<h2>Find a file in your folders</h2>
find_file.py
